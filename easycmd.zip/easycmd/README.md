# easycmd
easycmdcli
