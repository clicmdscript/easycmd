#!/bin/bash

cd /home/ubuntu
wget https://raw.githubusercontent.com/clicmdscript/easycmd/main/install_awscli.sh
chmod +x install_awscli.sh
./install_awscli.sh

